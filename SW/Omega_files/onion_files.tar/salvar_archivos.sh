rm onion_files.tar
tar -cvf onion_files.tar ./
scp onion_files.tar leoperez@192.168.3.105:
